import { Injectable } from '@angular/core';
import { GenericService } from './generic.service';

@Injectable({
    providedIn: 'root'
  })
  export class EmployeeService {

    constructor(private service: GenericService) { }

    public addEmployee(employee){
        this.service.sendPostRequest("add",employee).subscribe(result=>{
            debugger;
            console.log(result);
            return result;
        },error=>{

            console.log(error);
           
        })

    }
    public getAll():any{
        this.service.sendGetRequest("").subscribe(result=>{
            debugger;
            console.log(result);
            return result;
        },error=>{

            console.log(error);
           
        })

    }

  }
