import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators'; 
const baseApiIp ='http://localhost:3000/'; 
const httpOptions = {
  headers: new HttpHeaders({
  'Content-Type': 'application/json; charset=UTF-8',
  'Access-Control-Allow-Origin': '*',
  "Access-Control-Allow-Credentials": "true",
  'Access-Control-Allow-Headers': '*',
  'Access-Control-Allow-Methods': '*',
  //'Authorization': "Bearer " + sessionStorage.getItem("AuthToken"),
  })
 }; 
 

@Injectable({
  providedIn: 'root'
})
export class GenericService {

  constructor(private http: HttpClient) { }
  public sendGetRequest(url){
    return this.http.get(baseApiIp+url,httpOptions);
  }
  public sendPostRequest(url,data){

    return this.http.post(baseApiIp+url,data,httpOptions);

  }
}
