import { Component, OnInit } from '@angular/core';
import { Employee } from '../Models/employee';
import { EmployeeService } from '../Service/employee.service';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {
  employee=new Employee();
  employeeList:Employee[]=[];
  isCheck:boolean=false;

  constructor(private employeeService:EmployeeService) {
    this.employee.id=1;
    this.employee.name="ahmed";
    

   }

  ngOnInit(): void {
    
   this.isCheck=true;

    
  }
  getEmployees(){
    debugger;
   this.employeeList= this.employeeService.getAll();


  }
  add(){
    
    this.employeeList.push(this.employee);

    this.employeeService.addEmployee(this.employee);
    //this.getEmployees();
  }


}
